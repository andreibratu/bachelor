package domain

import java.util.*

class Entry(
    var entryTitle: String,
    var entryText: String,
    var entryDate: Date,
    var tags: Array<String>)