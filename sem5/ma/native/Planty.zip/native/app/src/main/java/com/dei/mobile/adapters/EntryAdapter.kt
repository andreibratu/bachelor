package com.dei.mobile.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.dei.mobile.R
import domain.Entry
import kotlinx.android.synthetic.main.entry_table_view.view.*
import java.text.DateFormatSymbols
import java.util.*

class EntryAdapter(private val entryDataset: Array<Entry>) :
        RecyclerView.Adapter<EntryAdapter.EntryViewHolder>()
{
    class EntryViewHolder(val entryLayout: ConstraintLayout) : RecyclerView.ViewHolder(entryLayout)

    private fun dateToString(date: Date) : String
    {
        val builder = StringBuilder()
        val dfs = DateFormatSymbols()
        var month = "N/A"
        val num = date.month
        val months: Array<String> = dfs.months
        if (num in 0..11) {
            month = months[num]
        }
        builder.append(date.date).append(" ").append(month)
        return builder.toString()
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntryViewHolder
    {
        // create a new view
        val entryLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.entry_table_view, parent, false) as ConstraintLayout
        entryLayout.getChildAt(0)
        return EntryViewHolder(entryLayout)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(holder: EntryViewHolder, position: Int)
    {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        holder.entryLayout.entry_title.text = entryDataset[position].entryTitle
        holder.entryLayout.entry_date.text = dateToString(entryDataset[position].entryDate)
        holder.entryLayout.entry_text.text = entryDataset[position].entryText
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = entryDataset.size
}