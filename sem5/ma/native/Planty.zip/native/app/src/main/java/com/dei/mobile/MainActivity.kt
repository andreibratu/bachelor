package com.dei.mobile

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dei.mobile.adapters.EntryAdapter
import domain.Entry
import java.util.*

const val EXTRA_MESSAGE = "com.dei.mobile.MESSAGE"

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager

    @Suppress("SameParameterValue")
    private fun buildDate(year: Int, month: Int, date: Int): Date
    {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.MONTH, month)
        calendar.set(Calendar.DATE, date)
        return calendar.time
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewManager = LinearLayoutManager(this)
        viewAdapter = EntryAdapter(arrayOf(
            Entry("Super cool", "Sunt foarte bine multumesc de intrebare lalalalaslsalfkaknfakjbfjkabfjkabfjkadbsajk", buildDate(2020, 6, 20), arrayOf("cool", "anxious")),
            Entry("Uite stam", "Ce scrie si mai sus", buildDate(2020, 6, 21), arrayOf("depressive", "worried"))
        ))

        recyclerView = findViewById<RecyclerView>(R.id.entry_recycler_view).apply {
            // use this setting to improve performance if you know that changes
            // in content do not change the layout size of the RecyclerView
            setHasFixedSize(true)
            // use a linear layout manager
            layoutManager = viewManager
            // specify an viewAdapter (see also next example)
            adapter = viewAdapter
        }
    }
}
