class GraphicalUI:

    def __init__(self):
        pass
        # Though luck, my dear.
